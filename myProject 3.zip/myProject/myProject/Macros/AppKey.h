//
//  AppKey.h
//  myProject
//
//  Created by cjf on 8/1/16.
//  Copyright © 2016 Jinfei Chen. All rights reserved.
//

#ifndef AppKey_h
#define AppKey_h


// 友盟AppKey
#define AppKeyUmeng  @"579eac0567e58e1fd40028f5"

#endif /* AppKey_h */
